<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-center"><?php echo e(__('Verify Your Email Address')); ?></div>
                <div class="card-body">
                    <?php if(session('resent')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                    </div>
                    <?php endif; ?>

                    <?php echo e(__('Kami telah mengirimkan pesan ke email kamu, Silahkan cek email sekarang')); ?>

                    <?php echo e(__('jika belum menerima email')); ?>, <a href="<?php echo e(route('verification.resend')); ?>"><?php echo e(__('KLIK DISINI UNTUK PESAN TERBARU')); ?></a>.
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RnD\Documents\Sekolah\Peduli_diri\resources\views/auth/verify.blade.php ENDPATH**/ ?>