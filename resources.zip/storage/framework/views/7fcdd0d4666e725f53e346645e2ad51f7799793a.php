<?php $__env->startSection('content'); ?>
<table class="table table-hover" style="width: 100%;">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama Perjalanan</th>
                        <th scope="col">Tanggal</th>
                        <th scope="col">Jam</th>
                        <th scope="col">Lokasi</th>
                        <th scope="col">Suhu Tubuh</th>
                        <th scope="col">
                            <button type="button" class="btn btn-primary btn-sm">
                                <a href="/home" style="color: white; text-decoration:none;">Tambah</a>
                            </button>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($data->firstItem() + $no); ?></th>
                        <td><?php echo e($isi->nama_perjalanan); ?></td>
                        <td><?php echo e($isi->tanggal); ?></td>
                        <td><?php echo e($isi->jam); ?></td>
                        <td><?php echo e($isi->lokasi); ?></td>
                        <td><?php echo e($isi->suhu_tubuh); ?>°</td>
                        <td>
                            <a href="#" class="ml-2 text-success"><i class="fa fa-edit"></i></a>
                            <a href="/delete/<?php echo e($isi->id); ?>" class="ml-3 text-danger"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="row">
                <div class=" col-md-6 mt-3">
                    Menampilkan <?php echo e($data->firstItem()); ?>

                    sampai <?php echo e($data->lastItem()); ?>

                    dari total <?php echo e($data->total()); ?> data
                </div>
                <div class="col-md-6 d-flex justify-content-end mt-2">
                    <?php echo e($data->links()); ?>

                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('perjalanan.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RnD\Documents\Sekolah\perjalanan\resources\views/perjalanan/profil.blade.php ENDPATH**/ ?>