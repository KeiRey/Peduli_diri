<?php $__env->startSection('content'); ?>


<form method="POST" action="/profile" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="form-group row">
        <label for="name" class="col-md-2 col-form-label text-md-right">Nama</label>

        <div class="col-md-6">
            <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e($user->name); ?>" required autocomplete="name" autofocus>

            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
    </div>

    <div class="form-group row">
        <label for="nik" class="col-md-2 col-form-label text-md-right">nik</label>

        <div class="col-md-6">
            <input id="nik" type="nik" class="form-control <?php if ($errors->has('nik')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nik'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nik" value="<?php echo e($user->nik); ?>" required autocomplete="nik">

            <?php if ($errors->has('nik')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nik'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
    </div>

    <div class="form-group row">
        <label for="gambar" class="col-md-2 col-form-label text-md-right">Profil</label>

        <div class="col-md-6">
            <input id="gambar" type="file" class="form-control <?php if ($errors->has('gambar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gambar'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="gambar" value="<?php echo e($user->gambar); ?>" autocomplete="gambar">

            <?php if ($errors->has('gambar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gambar'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
    </div>

    <div class="form-group row">
        <label for="email" class="col-md-2 col-form-label text-md-right">Email</label>

        <div class="col-md-6">
            <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e($user->email); ?>" required autocomplete="email">

            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
    </div>

    <div class="form-group row">
        <label for="no_telp" class="col-md-2 col-form-label text-md-right">No Telepon</label>
        <div class="col-md-6">
            <input id="no_telp" type="text" class="form-control <?php if ($errors->has('no_telp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_telp'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="no_telp" value="<?php echo e($user->no_telp); ?>" required autocomplete="no_telp" autofocus>

            <?php if ($errors->has('no_telp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_telp'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
    </div>

    <div class="form-group row">
        <label for="alamat" class="col-md-2 col-form-label text-md-right">Alamat</label>
        <div class="col-md-6">
            <textarea for="alamat" name="alamat" class="form-control <?php if ($errors->has('alamat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alamat'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required=""><?php echo e($user->alamat); ?></textarea>

            <?php if ($errors->has('alamat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alamat'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
    </div>

    <div class="form-group row">
        <label for="password" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>
        <div class="col-md-6">
            <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" autocomplete="new-password">

            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
    </div>

    <div class="form-group row">
        <label for="password-confirm" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>
        <div class="col-md-6">
            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" autocomplete="new-password">
        </div>
    </div>

    <div class="form-group row mb-0">
        <div class="col-md-6 offset-md-2">
            <a href="/profile" class="btn btn-danger">Kembali</a>
            <button type="submit" class="btn btn-primary">
                <i class="fa fa-pencil-alt"></i> Edit
            </button>
        </div>
    </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('perjalanan.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RnD\Documents\Sekolah\perjalanan\resources\views/Auth/editProfile.blade.php ENDPATH**/ ?>