<?php $__env->startSection('content'); ?>
    <div class="row mt-5 biasa-aja">
        <div class="col-md-3">
            <section id="team" class="team">
                <div class="container" data-aos="fade-up">
                    <div class="row">
                        <?php echo $__env->make('layouts.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-md-9">
            <div class="col-lg-12">
                <table class="table table-responsive table-hover">
                    <thead>
                        <tr>
                            <th scope="col" style="width: 4%;">#</th>
                            <th scope="col" style="width: 22%;">Nama Perjalanan</th>
                            <th scope="col" style="width: 14%;">Tanggal</th>
                            <th scope="col" style="width: 12%;">Jam</th>
                            <th scope="col" style="width: 14%;">Lokasi</th>
                            <th scope="col" style="width: 17%;">Suhu Tubuh</th>
                            <th scope="col" style="width: 15%;">
                                <a href="/create" class="btn btn-sm btn-success">Tambah</a>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($data->firstItem() + $no); ?></th>
                                <td><?php echo e(Str::upper($isi->nama_perjalanan)); ?></td>
                                <td><?php echo e($isi->tanggal); ?></td>
                                <td><?php echo e($isi->jam); ?></td>
                                <td><?php echo e($isi->lokasi); ?></td>
                                <td><?php echo e($isi->suhu_tubuh); ?>°</td>
                                <td>
                                    <a href="/delete/<?php echo e($isi->id); ?>" class="ml-4 text-danger"><i
                                            class="fa-solid fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="row">
                    <div class="col-md-6 mt-3">
                        Halaman
                        <?php echo e($data->currentPage()); ?>


                    </div>
                    <div class="col-md-6 d-flex justify-content-end mt-3">
                        <?php echo e($data->links()); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RnD\Documents\Sekolah\Peduli_diri\resources\views/perjalanan/index.blade.php ENDPATH**/ ?>