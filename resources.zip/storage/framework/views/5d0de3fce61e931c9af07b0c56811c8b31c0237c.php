<?php $__env->startSection('content'); ?>
<div class="row mt-5">
    <div class="col-md-12 biasa-aja">
               <div class="col-lg-12">
                     <a href="/user/cetak_pdf" target="blank" class="btn btn-sm btn-success mr-3">PDF USER</a>
                        <a href="/admin/cetak_pdf" target="blank" class="btn btn-sm btn-primary">PDF Admin</a>
                            <table class="table table-responsive table-hover mt-3">
                            <thead>
                                <tr>
                                    <th scope="col" style="width: 4%;">#</th>
                                    <th scope="col" style="width: 16%;">NIK</th>
                                    <th scope="col" style="width: 16%;">Nama</th>
                                    <th scope="col" style="width: 14%;">Role</th>
                                    <th scope="col" style="width: 16%;">Email</th>
                                    <th scope="col" style="width: 16%;">No Telpon</th>
                                    <th scope="col" style="width: 18%;">Alamat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no+1); ?></td>
                                        <td><?php echo e($isi->nik); ?></td>
                                        <td><?php echo e($isi->name); ?></td>
                                        <td><?php echo e($isi->level); ?></td>
                                        <td><?php echo e($isi->email); ?></td>
                                        <td><?php echo e($isi->no_telp); ?></td>
                                        <td><?php echo e($isi->alamat); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col-md-6 mt-3">
                                Halaman
                                <?php echo e($user->currentPage()); ?>

                               
                            </div>
                            <div class="col-md-6 d-flex justify-content-end mt-3">
                                <?php echo e($user->links()); ?>

                            </div>
                        </div>
                    </div>

    </div>
</div>
      

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'Index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RnD\Documents\Sekolah\Peduli_diri\resources\views/admin/index.blade.php ENDPATH**/ ?>