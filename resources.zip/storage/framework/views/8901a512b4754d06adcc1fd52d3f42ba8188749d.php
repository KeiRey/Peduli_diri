<?php $__env->startSection('content'); ?>
    <div class="col-md-6">
        <div data-aos="zoom-out" data-aos-delay="200">
            <img src="<?php echo e(asset('assets/images/Around the world-bro.png')); ?>" alt="Image" class="img-fluid">
        </div>
    </div>
    <div class="col-md-6 contents">
        <div class="row justify-content-center">
            <div class="col-md-8" data-aos="fade-up" data-aos-delay="200">
                <div class="mb-4">
                    <h3>Sign In</h3>
                </div>
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group first">
                        <input id="email" type="email" placeholder="Email"
                            class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email"
                            value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                    </div>
                    <div class="form-group last mb-4">

                        <input id="password" placeholder="Password" type="password"
                            class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required
                            autocomplete="current-password">

                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                    </div>

                    <div class="d-flex mb-3 align-items-center">
                        <label class="control control--checkbox mb-0"><span class="caption">
                                <?php echo e(__('Remember Me')); ?></span>
                            <input type="checkbox" checked="checked" name="remember" id="remember"
                                <?php echo e(old('remember') ? 'checked' : ''); ?> />
                            <div class="control__indicator"></div>
                        </label>
                    </div>

                    <input type="submit" value="Log In" class="btn btn-block btn-primary">
                    <div class="d-flex mt-3 align-items-center">
                        <a href="<?php echo e(route('register')); ?>" class="forgot-pass"> Belum Punya Akun ? </a>
                        <span class="ml-auto">

                            <?php if(Route::has('password.request')): ?>
                                <a class="forgot-pass" href=" <?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('Lupa Password?')); ?>

                                </a>
                            <?php endif; ?>
                        </span>
                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RnD\Documents\Sekolah\Peduli_diri\resources\views/auth/login.blade.php ENDPATH**/ ?>