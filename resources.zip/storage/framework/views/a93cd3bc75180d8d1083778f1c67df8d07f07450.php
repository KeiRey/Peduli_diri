<?php $__env->startSection('content'); ?>
<table class="table table-responsive table-hover">
    <thead>
        <tr>
            <th scope="col" style="width: 6%;">#</th>
            <th scope="col" style="width: 22%;">Nama Perjalanan</th>
            <th scope="col" style="width: 14%;">Tanggal</th>
            <th scope="col" style="width: 14%;">Jam</th>
            <th scope="col" style="width: 14%;">Lokasi</th>
            <th scope="col" style="width: 16%;">Suhu Tubuh</th>
            <th scope="col" style="width: 12%;">
                <a href="/create" class="btn btn-primary btn-sm">Tambah</a>
            </th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($data->firstItem() + $no); ?></th>
            <td><?php echo e($isi->nama_perjalanan); ?></td>
            <td><?php echo e($isi->tanggal); ?></td>
            <td><?php echo e($isi->jam); ?></td>
            <td><?php echo e($isi->lokasi); ?></td>
            <td><?php echo e($isi->suhu_tubuh); ?>°</td>
            <td >
                <a href="/delete/<?php echo e($isi->id); ?>" class="ml-4 text-danger"><i class="fa fa-trash"></i></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="row">
    <?php if(!empty($data)): ?>
    <div class="col-md-6 mt-3">
        Tampilan
        <?php echo e($data->firstItem()); ?>

        Sampai
        <?php echo e($data->lastItem()); ?>

        Item
    </div>
    <?php else: ?>
    <div class="col-md-6 mt-3">
        Data Masih Kosong
    </div>
    <?php endif; ?>
    <div class="col-md-6 d-flex justify-content-end mt-3">
        <?php echo e($data->links()); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('perjalanan.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RnD\Documents\Sekolah\perjalanan\resources\views/perjalanan/index.blade.php ENDPATH**/ ?>