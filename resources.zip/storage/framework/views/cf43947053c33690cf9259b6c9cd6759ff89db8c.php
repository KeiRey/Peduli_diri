<?php $__env->startSection('content'); ?>

<div class="alert alert-primary" role="alert">
    <h3>Profile</h3>
</div>
<table class="table table-hover">
    <tr>
        <td>Nama</td>
        <td>:</td>
        <td><?php echo e($user->name); ?></td>
    </tr>
    <tr>
        <td>NIK</td>
        <td>:</td>
        <td><?php echo e($user->nik); ?></td>
    </tr>
    <tr>
        <td>No Telpon</td>
        <td>:</td>
        <td><?php echo e($user->no_telp); ?></td>
    </tr>
    <tr>
        <td>Email</td>
        <td>:</td>
        <td><?php echo e($user->email); ?></td>
    </tr>
    <tr>
        <td>Alamat</td>
        <td>:</td>
        <td><?php echo e($user->alamat); ?></td>
    </tr>
</table>

<a href="/edit/profile/<?php echo e($user->id); ?>" class="btn btn-primary">Edit</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('perjalanan.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RnD\Documents\Sekolah\perjalanan\resources\views/Auth/profile.blade.php ENDPATH**/ ?>