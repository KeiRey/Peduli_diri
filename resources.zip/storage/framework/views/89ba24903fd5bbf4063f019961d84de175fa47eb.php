<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>
        <?php if(isset($title)): ?>
        <?php echo e(config('app.name')); ?> |
        <?php endif; ?>
        <?php echo e($title); ?>

    </title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/Capture-removebg-preview.png')); ?>" />
    <meta content="" name="description">

    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <link href="<?php echo e(asset('assets-form/vendor/select2/select2.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('assets-form/vendor/datepicker/daterangepicker.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('assets-form/css/main.css')); ?>" rel="stylesheet" media="all">

    <link rel="stylesheet" href="<?php echo e(asset ('assets-login/fonts/icomoon/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('assets-login/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('assets-login/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('assets-login/css/style.css')); ?>">
    <!-- Template Main CSS File -->
    <link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">

    <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ======= Hero Section ======= -->
    <section id="hero" class="hero d-flex align-items-center">

        <div class="container mt-5">
            <div class="row">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>

    </section><!-- End Hero -->


    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="<?php echo e(asset('assets-login/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-login/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-login/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-login/js/main.js')); ?>"></script>
    <script src="assets/vendor/purecounter/purecounter.js"></script>
    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js" integrity="sha384-VHvPCCyXqtD5DqJeNxl2dtTyhF78xXNXdkwX1CZeRusQfRKp+tA7hAShOK/B/fQ2" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/0cf2399774.js" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('assets-form/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-form/vendor/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-form/vendor/datepicker/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-form/vendor/datepicker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-form/js/global.js')); ?>"></script>
    <script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
    <?php echo Toastr::message(); ?>

    <!-- <script>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.error('<?php echo e($error); ?>', 'Error', {
                    closebutton : true,
                    progressbar : true
                });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </script> -->
    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>
    <!-- <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
</body>

</html><?php /**PATH C:\Users\RnD\Documents\Sekolah\Peduli_diri\resources\views/layouts/app.blade.php ENDPATH**/ ?>