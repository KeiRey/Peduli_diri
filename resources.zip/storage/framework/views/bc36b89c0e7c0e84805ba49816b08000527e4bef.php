[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Users\RnD\Documents\Sekolah\Peduli_diri\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>