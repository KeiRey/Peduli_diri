<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
    <div class="footer-top">
        <div class="container">
            <div class="row gy-4">
                <div class=" col-md-12 footer-info ">
                    <a href="/home" class="logo d-flex align-items-center">
                        <img src="<?php echo e(asset('assets/img/Capture-removebg-preview.png')); ?>" alt="">
                        <span>PeduliDiri</span>
                    </a>
                    <p style="color: black">Catat dan manage perjalanan anda.</p>
                    <!-- <div class="social-links mt-3">
                            <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
                            <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                            <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
                            <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
                        </div> -->
                </div>

            </div>
        </div>
    </div>

</footer>
<!-- End Footer --><?php /**PATH C:\Users\RnD\Documents\Sekolah\Peduli_diri\resources\views/layouts/footer.blade.php ENDPATH**/ ?>