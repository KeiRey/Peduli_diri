<?php $__env->startSection('content'); ?>

<h1>hai</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('perjalanan.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RnD\Documents\Sekolah\Peduli_diri\resources\views/Auth/ProfileEdit.blade.php ENDPATH**/ ?>