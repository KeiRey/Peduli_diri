<?php $__env->startSection('content'); ?>

<h3>Create</h3>
    <form action="/store" method="post">
        <?php echo csrf_field(); ?>
        <table>
            <tr>
                <td>Nama Perjalanan</td>
                <td>:</td>
                <td>
                    <input value="<?php echo e($edit->nama_perjalanan); ?>" type="text" name="nama_perjalanan">
                </td>
            </tr>
            <tr>
                <td>Tanggal</td>
                <td>:</td>
                <td>
                    <input value="<?php echo e($edit->tanggal); ?>" type="date" name="tanggal">
                </td>
            </tr>
            <tr>
                <td>jam</td>
                <td>:</td>
                <td>
                    <input value="<?php echo e($edit->jam); ?>" type="time" name="jam">
                </td>
            </tr>
            <tr>
                <td>Lokasi</td>
                <td>:</td>
                <td>
                    <input value="" type="text" name="lokasi">
                </td>
            </tr>
            <tr>
                <td>Suhu Tubuh</td>
                <td>:</td>
                <td>
                    <input value="" type="text" name="suhu_tubuh">
                </td>
            </tr>
            <tr>
                <td>
                    <input type="submit" value="Tambah">
                </td>
            </tr>
        </table>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('perjalanan.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RnD\Documents\Sekolah\perjalanan\resources\views/perjalanan/edit.blade.php ENDPATH**/ ?>