<!DOCTYPE html>
<html>
<head>
	<title>Data User Peduli Diri</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
        <h4>Data User Peduli Diri</h4>
    </center>
 
	<table class='table table-bordered'>
		<thead>
			<tr>
				<th align="center">No</th>
                <th><center>  NIK </center></th>
				<th><center>  Role </center></th>
				<th><center>  Nama </center></th>
				<th><center>  Email </center></th>
				<th><center>  Telepon </center></th>
				<th><center>  Alamat </center></th>
			</tr>
		</thead>
		<tbody>
		
				<?php $i=1 ?>
				<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($i++); ?></td>
					<td><?php echo e($p->nik); ?></td>
					<td><?php echo e($p->level); ?></td>
					<td><?php echo e($p->name); ?></td>
					<td><?php echo e($p->email); ?></td>
					<td><?php echo e($p->no_telp); ?></td>
					<td><?php echo e($p->alamat); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</tbody>
	</table>
 
</body>
</html><?php /**PATH C:\Users\RnD\Documents\Sekolah\Peduli_diri\resources\views/admin/user_pdf.blade.php ENDPATH**/ ?>