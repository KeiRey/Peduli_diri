<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\RnD\Documents\Sekolah\Peduli_diri\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>