  <div class="col-lg-12 col-md-12 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
      
      <div class="member">
          <div class="member-img">
              <?php if(empty(Auth::user()->gambar)): ?>
                  <img src="<?php echo e(Avatar::create(Auth::user()->name)->toBase64()); ?>" class="img-fluid" alt="">
              <?php else: ?>
                  <img src="<?php echo e(url('images')); ?>/<?php echo e(Auth::user()->gambar); ?>" class="img-fluid" alt="">
              <?php endif; ?>
              <div class="social">
                 <a href="/profile"><i class="bi bi-person-circle"></i></a>
                  <a href="/logout"><i class="bi bi-box-arrow-left"></i></a>
              </div>
          </div>
          <div class="member-info">
             <h4><?php echo e(Auth::user()->name); ?></h4>
              <p ><?php echo e(Auth::user()->email); ?></p>
          </div>
      </div>
  </div>
<?php /**PATH C:\Users\RnD\Documents\Sekolah\Peduli_diri\resources\views/layouts/profil.blade.php ENDPATH**/ ?>