<?php echo e($slot); ?>

<?php /**PATH C:\Users\RnD\Documents\Sekolah\Peduli_diri\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>